<?php 
$db_name = "shuttlebus";
$mysql_username = "root";
$mysql_password = "shuttle*2017";
$server_name = "localhost";
$conn = mysqli_connect($server_name, $mysql_username, $mysql_password,$db_name);
 
?>	